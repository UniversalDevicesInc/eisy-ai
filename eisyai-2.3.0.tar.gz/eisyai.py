
#!/usr/bin/env python3
# Main routine for IoX Plugin. 
# Do NOT Modify 

import udi_interface, os, sys, json, time,shutil,grp
import version

PLUGIN_FILE_NAME = 'eisyai.iox_plugin.json'
PLUGIN_FILE_NAME_DEST = f"{os.getcwd()}/{PLUGIN_FILE_NAME}"
DATA_PATH = f"{os.getcwd()}/data"
PLUGIN_FILE_NAME_SRC = f"{DATA_PATH}/{PLUGIN_FILE_NAME}"
VENV_PATH = f"{os.getcwd()}/.venv"
PERSIST_PATH = f"{os.getcwd()}/persist"

LOGGER = udi_interface.LOGGER

def securePersistDir():
    try:
        os.makedirs(PERSIST_PATH, exist_ok=True)
        uid = os.getuid()
        gid = grp.getgrnam('polyglot').gr_gid
        os.chown(PERSIST_PATH, uid, gid)
        os.chmod(PERSIST_PATH, 0o770)
        for root, dirs, files in os.walk(PERSIST_PATH):
            for name in dirs + files:
                path = os.path.join(root, name)
                os.chown(path, uid, gid)
                os.chmod(path, 0o770)
    except Exception as ex:
        LOGGER.error(str(ex))

def configurePluginFile():
   if not os.path.exists(PLUGIN_FILE_NAME):
        if not os.path.exists(PLUGIN_FILE_NAME_SRC):
            return False
        else:
            try:
                shutil.copy(PLUGIN_FILE_NAME_SRC, PLUGIN_FILE_NAME_DEST)
            except Exception as ex:
                LOGGER.error(str(ex))
                return False
   return True


if __name__ == '__main__':
    try:
        polyglot = udi_interface.Interface([])
        polyglot.start(version.ud_plugin_version)
        plugin = None
        if not configurePluginFile(): 
            polyglot.Notices['config']=f"{PLUGIN_FILE_NAME} does not exist. Uplaod it using Configuration tab Zip File Upload then Restart ..."
        else:
            polyglot.Notices.clear()
            from EisyaiControllerNode import EisyaiControllerNode
            controller = EisyaiControllerNode(polyglot)
            polyglot.ready()
            if not os.path.exists(VENV_PATH):
                securePersistDir()
            polyglot.runForever()
    
    except (KeyboardInterrupt, SystemExit):
        LOGGER.info('exiting ...')
        sys(0)
