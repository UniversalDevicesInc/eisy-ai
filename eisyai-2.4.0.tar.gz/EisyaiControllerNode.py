
from pathlib import Path
import re

import udi_interface, os, shutil, sys, json, time, threading
LOGGER = udi_interface.LOGGER
Custom = udi_interface.Custom
from start_eisyai import start_eisyai

DATA_PATH='./data'
class EisyaiControllerNode(udi_interface.Node):
    id = 'eisyaicontroll'
    """This is a list of properties that were defined in the nodedef"""
    drivers = [{'driver': 'ST', 'value': 0, 'uom': 25, 'name': 'Status'}]
    children = []

    def __init__(self, polyglot, controller='eisyaicontroll',
        address='eisyaicontroll', name='eisy-ai'):
        super().__init__(polyglot, controller, address, name)
        self.Parameters = Custom(polyglot, 'customparams')
        self.poly.addNode(self, conn_status='ST')
        self.poly.subscribe(polyglot.START, self.__start, address)
        self.poly.subscribe(polyglot.CUSTOMPARAMS, self.parameterHandler)
        self.poly.subscribe(polyglot.POLL, self.__poll)
        self.poly.subscribe(polyglot.STOP, self.__stop)
        self.poly.subscribe(polyglot.CONFIG, self.__configHandler)
        self.poly.subscribe(polyglot.CONFIGDONE, self.__configDoneHandler)
        self.poly.subscribe(polyglot.ADDNODEDONE, self.__addNodeDoneHandler)
        self.poly.subscribe(polyglot.DELNODEDONE, self.__removeNodeDoneHandler)
        self.poly.subscribe(polyglot.CUSTOMNS, self.__customNSHandler)
        self.poly.subscribe(polyglot.CUSTOMDATA, self.customDataHandler)
        self.poly.subscribe(polyglot.DISCOVER, self.discover)
        self.poly.subscribe(polyglot.BONJOUR, self.__bonjourHandler)
        self.configDone = threading.Condition()
        self.configDoneAlready = False

    def getUOM(self, driver: str):
        try:
            for driver_def in self.drivers:
                if driver_def['driver'] == driver:
                    return driver_def['uom']
            return None
        except Exception as ex:
            return None


    def __configHandler(self, param):
        try:
            if os.path.exists(DATA_PATH):
                self.filesUploaded(DATA_PATH)
                shutil.rmtree(DATA_PATH)
            if param:
                return self.processConfig(param)
        except Exception as ex:
            LOGGER.warn(str(ex))

        return True

    def __bonjourHandler(self, message):
        try:
            command = message['command']
            if command == None or command != "bonjour": 
                return
            mdns = message['mdns']
            self.processMDNSResults(mdns)
        except Exception as ex:
            LOGGER.error(str(ex))

    def __start(self):
        LOGGER.info(f'Starting... ')
        try:
            self.poly.setCustomParamsDoc()
            if not self.configDoneAlready:
                with self.configDone:
                    result = self.configDone.wait(timeout=10)
                    if not result:
                        #timedout
                        LOGGER.info("timed out while waiting for configDone")
                        self.__updateStatus(0, True) 
                        return False
            if self.start():
                self.__addAllNodes()
                self.poly.updateProfile()
                self.__updateStatus(1, True) 
                return True
            else:
                LOGGER.info("failed processing config ...")
                self.__updateStatus(0, True) 
                return False
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def __stop(self):
        LOGGER.info(f'Stopping ... ')
        self.stop()
        self.__updateStatus(0,True)
        return True

    def __poll(self, polltype):
        if not self.configDoneAlready:
            return
        if 'shortPoll' in polltype:
            self.shortPoll()
        elif 'longPoll' in polltype:
            self.longPoll()

    def __addAllNodes(self):
        config = self.poly.getConfig()
        if config is None or config['nodes'] is None or len(config['nodes']) <= 0:
            config = {}
            config['nodes'] = []

        for node in config['nodes']:
            if node['nodeDefId'] == self.id:
                continue
            if not self.__addNodeFromConfig(node):
                return
        LOGGER.info(f'Done adding nodes ...')
    
    def __getNodeClass(self, nodeDefId:str)->str:
        for child in self.children:
            if child['id'] == nodeDefId:
                return child['node_class']
        return None

    def __addNodeFromConfig(self, node_info) ->bool:
        return False

    def __addNodeDoneHandler(self, node):
        try:
            if node['nodeDefId'] == self.id:
                return True
            return self.addNodeDone(node)

        except ValueError as err:
            LOGGER.error(str(x))
            return False

    def __removeNodeDoneHandler(self, node):
        try:
            if node['nodeDefId'] == self.id:
                return True
            return self.nodeRemoved(node)

        except ValueError as err:
            LOGGER.error(str(x))
            return False

    def __configDoneHandler(self):
        rc = self.processConfigDone()
        with self.configDone:
            self.configDoneAlready = True
            self.configDone.notifyAll()
        return rc

    def __customNSHandler(self, key, data):
        self.customParamHandler(key, data)

    def __updateStatus(self, value, force: bool):
        return self.setDriver("ST", value, 2, force)

    def __getStatus(self):
        return self.getDriver("ST")

    def __query(self, command):
        nodes = self.poly.getNodes()
        if nodes is None or len(nodes) == 0:
            return True
        for n in nodes:
            node = nodes[n]
            if node is None:
                continue
            else:
                node.query()

    #######################
    ###### NOTICES ########
    #######################
    def clearNotices(self):
        """
        Call this method to remove the blue ribbon that requests the attention of the user
        """
        self.poly.Notices.clear()

    def setNotices(self, key:str, notice:str) :
        """
        Call this method to add a blue ribbon with notice for the customer to take action
        This is a dictionary. So, you would need to provide the key (i.e. the parameter's name)
        And a string that will be displayed in the ribbon
        """
        if key == None or notice == None:
            LOGGER.error("setNotices requires both the key and the notice.")
            return
        self.poly.Notices[key]=notice

    #####################
    ###### NODES ########
    #####################

    def getNode(self, address:str):
        """
        Call this method to get a node and then call its methods for updating
        their state in IoX. Take a look at the class that implements this node
        it's always a good idea to use isinstance to make sure you are dealing 
        with the correct node.
        The address is the address of the node.
        """
        return self.poly.getNode(address)

    
    def addNode(self, address:str, nodeDefId:str, name:str, parent:str=None):
        """
        "Call this method to create dynamic node. The parent will always be the controller 
        "for this node
        """
        if address == None or nodeDefId == None:
            LOGGER.error("need address and nodeDefId ...")
            return False

        if parent == None:
            parent = address  

        nodeInfo={}
        nodeInfo['primaryNode']=parent
        nodeInfo['address']=address
        nodeInfo['name']=name
        nodeInfo['nodeDefId']=nodeDefId
        return self.__addNodeFromConfig(nodeInfo)

    #############################
    ###### CUSTOM PARAMS ########
    #############################
    def createCustomParam(self, key):
        """
        Creates a user defined/custom parameter for key/value pairs of your own and stores in the 
        database. Whenever a key is updated the customParamHandler (below) is called with the 
        key and its updated value. example:
        myKey = self.createCustomParam('myKey')
        self.updateCustomParam(myKey, "my value" )
        """ 
        try:
            return Custom(self.poly, key)
        except Exception as ex:
            LOGGER.error(f'create custom param failed ...')
            return None

    def updateCustomParam(self, key:Custom, value:str):
        """
        Updates a user defined param. Whenever this method is called, customParamHandler is called
        with the updated values.
        """
        try:
            key = value
        except Exception as ex:
            LOGGER.error(f'failed updating custom param ...' )
    
    def sendPushNotification(self, title:str, body:str):
        """
        Send push notifications to UD Mobile
        """
        if title == None or body == None:
            return
        try:
            self.poly.udm_alert(title, body)
        except Exception as ex:
            LOGGER.error(str(ex))

    def __discover(self):
        return self.discover()

    ###
    # This is a list of commands that were defined in the nodedef
    ###
    commands = {'discover': __discover, 'x_query': __query}

    """########WARNING: DO NOT MODIFY THIS LINE!!! NOTHING BELOW IS REGENERATED!#########"""

    runtime_config = None

    
    #############################
    ###### START|STOP ###########
    #############################
    ####

    def start(self)->bool:
        """
        MANDATORY if and only if you have commands
        This method is called at start so that you can do whatever initialization
        you need. If you return false, the status of the controller node shows 
        disconnected. So, make sure you return the correct status.
        """
        try:
            global runtime_config
            if runtime_config is None:
                self.setNotices("Eisy AI", "Runtime configuration is not set")
                return False
            runtime_config = json.loads(runtime_config)
            notice = start_eisyai(runtime_config, self.poly)
            if notice:
                self.setNotices("Eisy AI", notice)
            else:
                # Clears a prior no-API-key notice once the config is fixed
                # and this restarts -- Notices persists across restarts
                # (every mutation saves), so a stale one would otherwise
                # never go away on its own.
                self.poly.Notices.delete("Eisy AI")
            return True

        except Exception as ex:
            self.setNotices("Eisy AI", str(ex))
            LOGGER.error(f'start failed .... ')
            LOGGER.error(str(ex))
            return False

    def stop(self)->bool:
        """
        This method is called at stop so that you can do whatever cleaning up 
        that's necessary. The result is not checked so make sure everything is 
        cleaned up
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(f'stop failed .... ')
            return False


    #############################
    ###### PARAMS ###############
    #############################

    def parameterHandler(self, params:Custom)->bool:
        """
        This method is called with the custom parameters provided by the user.
        It is a dictionary so you get the parameter name/key and the value. e.g.
        params['path']
        """
        try:
            global runtime_config
            for key, value in params.items():
                if key == "Configuration":
                    runtime_config = self.extract_json_block(value)

            return True
        except Exception as ex:
            LOGGER.error(f'process param failed .... ')
            LOGGER.error(str(ex))
            return False

    def extract_json_block(self, text: str) -> str:
        try:
            match = re.search(r"```json\s*(.*?)\s*```", text, re.DOTALL)
            return match.group(1) if match else text
        except Exception as ex:
            LOGGER.error(f'extract_json_block failed .... ')
            return None 

    def customParamHandler(self, key, value):
        """
        This method is called when a custom value (key/value) pair that's stored in the 
        database is changed. You can use this method to manage custom parameters of your own
        in the database.
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(f'process custom param failed .... ')
            return False

    def customDataHandler(self, data):
        """
        Rarely used.
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(ex)
    
    #####################
    ###### NODES ########
    #####################

    def getNodeAddress(self, nodedef_id):
        """
        This method is called every time a node is added so that you can map it to 
        anything else you want. 
        """
        try:
            #do any mapping you wish. 
            return nodedef_id
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def addNodeDone(self, node)->bool:
        """
        " This method is called when adding a node to the system is completed successfully. Make sure you use isinstance
        " to ensure it's your node and then do any additional processing necessary.
        """
        try:
            ###You can store your nodes in a dictionary for mapping or otherwise such as
            #if node == None:
            #   return False
            #self.nodes[node.address] = node
            ###
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def nodeRemoved(self, node)->bool:
        """
        This method is called when a node as been removed from the system
        """
        try:
            ###if you stored your nodes a dictionary, delete them 
            #if node == None:
            #   return False
            #del self.nodes[node.address]
            ###
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    

    #####################
    ###### POLL #########
    #####################

    def shortPoll(self)->bool:
        """
        This method is called at every short poll interval. The result is not checked
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def longPoll(self)->bool:
        """
        This method is called at every long poll interval. The result is not checked
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False


    ##########################
    ###### FILE UPLOAD #######
    ##########################

    def filesUploaded(self, path:str)->bool:
        """
        This method is called when files are uplaoded. The path is the directory to which you can find the files
        Do whatever you need with the files because they will be removed once you are done.
        """
        try:
            pass
            ###copy files to your desired directory, something like this:
            #file_path = os.path.join(path, filename)
            #if os.path.isfile(file_path):
            #    dest_path = os.path.join('./', filename)
            #    shutil.copy(file_path, dest_path)
            ###
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    ##########################
    ###### CONFIG ############
    ##########################

    def processConfig(self, config):
        """
        This method is called upon start and gives you all the configuration parameters
        used to initialize this plugin including the store, version, etc.
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def processConfigDone(self)->bool:
        """
        This method is called with the configuration is done. This is rarely used as its main function is to facilitate 
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    #############################
    ###### DISCOVERY ############
    #############################

    def discover(self)->bool:
        """
        This method is called by IoX to discover  
        nodes/devices or service
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(f'discover failed .... ')
            return False

    def searchForDevicesUsingMDNS(self, type:str, subtypes:str, protocol:str):
        """
        You can search the network using mDNS. To do so, call this method
        type : string = is the type of device you are looking for. If None, then everything
        subtypes : string = is a list of subtypes [string] you are looking for. If None, then everything
        protocol : string = either udp or tcp. If None, then everything
        If any results, processMDNSResults method will be called with a list of devices and their info
        """
        self.poly.bonjour(type, subtypes, protocol)

    def processMDNSResults(self, results:[]):
        """
        If search using mDNS is successful, this method is called with an array of devices. 
        """
        try:
            # Fill out this method based on the results
            return
        except Exception as ex:
            LOGGER.error(str(ex))

        
